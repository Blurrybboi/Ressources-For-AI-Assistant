# Other Usage of Flakes

So far, we have extensively used Flakes to manage NixOS configurations. In this section, I
will provide a brief introduction to additional features and command-line options commonly
used with Flakes.
