# Testing

TODO

## References

- [Integration testing with NixOS virtual machines - nix.dev](https://nix.dev/tutorials/nixos/integration-testing-using-virtual-machines.html)
- [NixOS Testing library](https://wiki.nixos.org/wiki/NixOS_Testing_library)
- [Testing within NixOS - NixOS Manual](https://nixos.org/manual/nixos/stable/index.html#sec-nixos-tests)
- [Testers - Nixpkgs Manual](https://nixos.org/manual/nixpkgs/unstable/#chap-testers)
- [Unveiling the Power of the NixOS Integration Test Driver (Part 1)](https://nixcademy.com/2023/10/24/nixos-integration-tests/)
- [Unveiling the Power of the NixOS Integration Test Driver (Part 2)](https://nixcademy.com/2023/12/01/nixos-integration-tests-part-2/)
- [nix flake check - Nix Reference Manual](https://nixos.org/manual/nix/stable/command-ref/new-cli/nix3-flake-check)
