(recipes)=
# Recipes

```{toctree}
:maxdepth: 1

add-binary-cache.md
Automatic environments <direnv>
sharing-dependencies.md
Managing remote sources <./dependency-management.md>
Python development environment <./python-environment.md>
post-build-hook.md
continuous-integration-github-actions.md
```
