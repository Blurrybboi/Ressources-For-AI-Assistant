(guides)=
# Guides

These sections contains guides to getting things done.

```{toctree}
:glob:
:maxdepth: 2

./recipes/index.md
./best-practices.md
./troubleshooting.md
./faq.md
```
