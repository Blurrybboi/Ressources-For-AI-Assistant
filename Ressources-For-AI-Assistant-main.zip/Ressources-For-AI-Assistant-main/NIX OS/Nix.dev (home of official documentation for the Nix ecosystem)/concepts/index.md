(concepts)=
# Concepts

These sections contains explanations of history and ideas in the Nix ecosystem.

```{toctree}
:glob:
:maxdepth: 2

flakes.md
faq.md
```
