(reference)=
# Reference

These sections contains collections of detailed technical descriptions.

```{toctree}
:glob:
:maxdepth: 2

glossary.md
./nix-manual.md
Nixpkgs manual <https://nixos.org/manual/nixpkgs/stable/>
NixOS manual <https://nixos.org/manual/nixos/stable/>
Community projects <https://github.com/nix-community/>
Support tools <https://github.com/nix-community/awesome-nix>
../recommended-reading.md
pinning-nixpkgs.md
```
