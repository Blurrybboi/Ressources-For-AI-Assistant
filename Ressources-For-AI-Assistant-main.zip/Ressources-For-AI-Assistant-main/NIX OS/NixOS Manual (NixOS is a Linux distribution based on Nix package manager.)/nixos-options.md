# Configuration Options {#ch-options}

```{=include=} options
id-prefix: opt-
list-id: configuration-variable-list
source: @NIXOS_OPTIONS_JSON@
```
