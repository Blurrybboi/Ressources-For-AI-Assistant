# Installing Nix from Source

If no binary package is available or if you want to hack on Nix, you
can build Nix from its Git repository.
