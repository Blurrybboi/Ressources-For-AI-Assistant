# Experimental Commands

This section lists [experimental commands](@docroot@/development/experimental-features.md#xp-feature-nix-command).

> **Warning**
>
> These commands may be removed in the future, or their syntax may
> change in incompatible ways.
