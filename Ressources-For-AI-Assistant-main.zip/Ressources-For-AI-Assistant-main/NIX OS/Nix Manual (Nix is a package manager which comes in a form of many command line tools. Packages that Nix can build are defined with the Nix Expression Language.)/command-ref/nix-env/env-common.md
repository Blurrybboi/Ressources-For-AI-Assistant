# Environment variables

- `NIX_PROFILE`

  Location of the Nix profile. Defaults to the target of the symlink
  `~/.nix-profile`, if it exists, or `/nix/var/nix/profiles/default`
  otherwise.
