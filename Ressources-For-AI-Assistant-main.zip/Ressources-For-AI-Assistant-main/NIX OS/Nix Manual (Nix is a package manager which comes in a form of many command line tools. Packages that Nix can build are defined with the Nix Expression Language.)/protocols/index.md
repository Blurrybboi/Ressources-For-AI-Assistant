# Protocols

This chapter documents various developer-facing interfaces provided by
Nix.
