This section lists advanced topics related to builds and builds performance
