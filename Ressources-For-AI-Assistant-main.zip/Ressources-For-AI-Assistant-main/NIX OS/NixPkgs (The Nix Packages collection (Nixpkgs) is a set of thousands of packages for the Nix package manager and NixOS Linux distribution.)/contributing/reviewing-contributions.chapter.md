# Reviewing contributions {#chap-reviewing-contributions}

This section has been moved to [CONTRIBUTING.md](https://github.com/NixOS/nixpkgs/blob/master/CONTRIBUTING.md).

## Package updates {#reviewing-contributions-package-updates}

This section has been moved to [pkgs/README.md](https://github.com/NixOS/nixpkgs/blob/master/pkgs/README.md).

## New packages {#reviewing-contributions-new-packages}

This section has been moved to [pkgs/README.md](https://github.com/NixOS/nixpkgs/blob/master/pkgs/README.md).

## Module updates {#reviewing-contributions-module-updates}

This section has been moved to [nixos/README.md](https://github.com/NixOS/nixpkgs/blob/master/nixos/README.md).

## New modules {#reviewing-contributions-new-modules}

This section has been moved to [nixos/README.md](https://github.com/NixOS/nixpkgs/blob/master/nixos/README.md).

## Individual maintainer list {#reviewing-contributions-individual-maintainer-list}

This section has been moved to [maintainers/README.md](https://github.com/NixOS/nixpkgs/blob/master/maintainers/README.md).

## Maintainer teams {#reviewing-contributions-maintainer-teams}

This section has been moved to [maintainers/README.md](https://github.com/NixOS/nixpkgs/blob/master/maintainers/README.md).

## Other submissions {#reviewing-contributions-other-submissions}

This section has been moved to [CONTRIBUTING.md](https://github.com/NixOS/nixpkgs/blob/master/CONTRIBUTING.md).

## Merging pull requests {#reviewing-contributions--merging-pull-requests}

This section has been moved to [CONTRIBUTING.md](https://github.com/NixOS/nixpkgs/blob/master/CONTRIBUTING.md).
