---
title: Scores by release date
parent: Aider LLM Leaderboards
nav_order: 200
---

## LLM code editing skill by model release date

[![connecting to many LLMs](/assets/models-over-time.svg)](https://aider.chat/assets/models-over-time.svg)

